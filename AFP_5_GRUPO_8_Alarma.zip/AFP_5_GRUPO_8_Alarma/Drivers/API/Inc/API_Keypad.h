
#ifndef KEYPAD_H_
#define KEYPAD_H_

#include "stm32f4xx_hal.h"

// Prototipos de funciones públicas
void keypad_init();
char keypad_getkey();

#endif /* KEYPAD_H_ */
